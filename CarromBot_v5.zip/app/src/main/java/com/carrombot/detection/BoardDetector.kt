package com.carrombot.detection

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

/**
 * DETECTION PIPELINE:
 * 1. Downscale frame (1/3) for speed
 * 2. Convert to grayscale
 * 3. Sobel edge detection
 * 4. Find rectangular board from edge lines (Hough-style scan)
 * 5. Crop to board region
 * 6. Blob detection inside board
 * 7. Filter blobs by circularity (4π·area/perimeter²)
 * 8. Classify by radius: striker=largest, pucks=medium
 * 9. Least-squares circle fitting for sub-pixel accuracy
 * 10. Scale coords back to full resolution
 */
object BoardDetector {

    data class Circle(
        val x: Float,       // Full-res X
        val y: Float,       // Full-res Y
        val radius: Float,  // Full-res radius
        val centerDotX: Float = x,
        val centerDotY: Float = y,
        val confidence: Float = 1f
    )

    data class Board(
        val left: Float, val top: Float,
        val right: Float, val bottom: Float
    ) {
        val width  get() = right - left
        val height get() = bottom - top
        val centerX get() = (left + right) / 2f
        val centerY get() = (top + bottom) / 2f
        // Puck radius = ~7.5% of board width (real carrom proportion)
        val puckRadius   get() = width * 0.075f
        val strikerRadius get() = width * 0.090f
        // Pocket centers at 4 corners (inset by ~4% of board size)
        val pockets get() = listOf(
            left  + width  * 0.042f to top    + height * 0.042f,
            right - width  * 0.042f to top    + height * 0.042f,
            left  + width  * 0.042f to bottom - height * 0.042f,
            right - width  * 0.042f to bottom - height * 0.042f
        )
        // Baseline Y where striker sits (bottom of board + small gap)
        val baselineY get() = bottom + height * 0.035f
    }

    data class GameState(
        val board: Board?,
        val striker: Circle?,
        val playerPucks: List<Circle>,   // Teal/dark pucks
        val opponentPucks: List<Circle>, // Pink pucks
        val queen: Circle?,              // Blue/cyan queen
        val isValid: Boolean,
        val strikerForce: Float = 0.8f,
        val powerLevel: Float = 0.7f
    )

    // Scale factor for processing (process at 1/3 for speed)
    private const val SCALE = 3

    // Tracking: previous positions for Kalman-style smoothing
    private var prevStriker: Circle? = null
    private var prevBoard: Board? = null
    private val prevPucks = mutableListOf<Circle>()

    // ── Main entry ────────────────────────────────────────────────────────────

    fun analyze(bmp: Bitmap): GameState {
        val fw = bmp.width; val fh = bmp.height

        // Step 1: Downscale for fast processing
        val sw = fw / SCALE; val sh = fh / SCALE
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, false)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        small.recycle()

        // Step 2: Grayscale
        val gray = toGray(pixels, sw, sh)

        // Step 3: Sobel edges
        val edges = sobelEdge(gray, sw, sh)

        // Step 4: Detect board rectangle
        val board = detectBoard(pixels, edges, sw, sh, fw, fh)
            ?: prevBoard
            ?: estimateBoard(fw, fh)

        prevBoard = board

        // Step 5: Scan board region for color blobs
        val bl = (board.left   / SCALE).toInt().coerceIn(0, sw - 1)
        val bt = (board.top    / SCALE).toInt().coerceIn(0, sh - 1)
        val br = (board.right  / SCALE).toInt().coerceIn(0, sw - 1)
        val bb = (board.bottom / SCALE).toInt().coerceIn(0, sh - 1)

        val strikerS    = detectStriker(pixels, sw, bl, bt, br, bb)
        val playerS     = detectColorPucks(pixels, sw, bl, bt, br, bb, PuckColor.TEAL)
        val opponentS   = detectColorPucks(pixels, sw, bl, bt, br, bb, PuckColor.PINK)
        val queenS      = detectColorPucks(pixels, sw, bl, bt, br, bb, PuckColor.CYAN)

        // Step 6: Scale back to full resolution + circle fit
        fun scaleUp(c: Circle) = Circle(
            x = c.x * SCALE,
            y = c.y * SCALE,
            radius = c.radius * SCALE,
            centerDotX = c.centerDotX * SCALE,
            centerDotY = c.centerDotY * SCALE,
            confidence = c.confidence
        )
        fun scaleList(list: List<Circle>) = list.map { scaleUp(it) }

        val striker   = strikerS?.let { scaleUp(it) }?.let { smoothStriker(it) }
        val players   = scaleList(playerS)
        val opponents = scaleList(opponentS)
        val queen     = queenS.maxByOrNull { it.radius }?.let { scaleUp(it) }

        // Step 7: Classify by board-measured radius
        // Filter out anything too small or too large vs expected puck size
        val expPuck = board.puckRadius
        fun inPuckRange(c: Circle) = c.radius in expPuck * 0.55f..expPuck * 1.45f

        val validPlayers   = players.filter { inPuckRange(it) }
        val validOpponents = opponents.filter { inPuckRange(it) }
        val validQueen     = if (queen != null && inPuckRange(queen)) queen else null

        val force = detectForceBar(pixels, sw, sh)
        val power = detectPowerBar(pixels, sw, sh)

        prevPucks.clear(); prevPucks.addAll(validPlayers + validOpponents)

        return GameState(
            board         = board,
            striker       = striker,
            playerPucks   = validPlayers,
            opponentPucks = validOpponents,
            queen         = validQueen,
            isValid       = striker != null && (validPlayers.isNotEmpty() || validOpponents.isNotEmpty()),
            strikerForce  = force,
            powerLevel    = power
        )
    }

    // ── Grayscale ─────────────────────────────────────────────────────────────

    private fun toGray(pixels: IntArray, w: Int, h: Int): IntArray {
        return IntArray(w * h) { i ->
            val p = pixels[i]
            (Color.red(p) * 77 + Color.green(p) * 150 + Color.blue(p) * 29) shr 8
        }
    }

    // ── Sobel edge detection ──────────────────────────────────────────────────

    private fun sobelEdge(gray: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val gx = -gray[(y-1)*w+(x-1)] + gray[(y-1)*w+(x+1)] +
                         -2*gray[y*w+(x-1)]   + 2*gray[y*w+(x+1)] +
                         -gray[(y+1)*w+(x-1)] + gray[(y+1)*w+(x+1)]
                val gy = -gray[(y-1)*w+(x-1)] - 2*gray[(y-1)*w+x] - gray[(y-1)*w+(x+1)] +
                          gray[(y+1)*w+(x-1)] + 2*gray[(y+1)*w+x] + gray[(y+1)*w+(x+1)]
                out[y*w+x] = sqrt((gx*gx + gy*gy).toDouble()).toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    // ── Board detection via corner pockets (very dark circles) ───────────────

    private fun detectBoard(pixels: IntArray, edges: IntArray, w: Int, h: Int, fw: Int, fh: Int): Board? {
        // Pockets are very dark — find 4 dark clusters near expected corners
        val darkPts = mutableListOf<Pair<Int,Int>>()
        for (y in 0 until h step 3) {
            for (x in 0 until w step 3) {
                val p = pixels[y*w+x]
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (r < 55 && g < 55 && b < 55) darkPts.add(x to y)
            }
        }
        if (darkPts.size < 16) return null

        // Cluster dark points
        val clusters = clusterPts(darkPts, 30f).filter { it.size > 4 }.sortedByDescending { it.size }.take(6)
        if (clusters.size < 4) return null

        val centers = clusters.map { c -> c.map{it.first}.average().toFloat() to c.map{it.second}.average().toFloat() }

        // Find bounding rect of pocket centers
        val minX = centers.minOf { it.first }
        val minY = centers.minOf { it.second }
        val maxX = centers.maxOf { it.first }
        val maxY = centers.maxOf { it.second }
        val boardW = maxX - minX; val boardH = maxY - minY
        if (boardW < w * 0.3f || boardH < h * 0.3f) return null

        return Board(
            left   = (minX * SCALE).coerceIn(0f, fw.toFloat()),
            top    = (minY * SCALE).coerceIn(0f, fh.toFloat()),
            right  = (maxX * SCALE).coerceIn(0f, fw.toFloat()),
            bottom = (maxY * SCALE).coerceIn(0f, fh.toFloat())
        )
    }

    private fun estimateBoard(fw: Int, fh: Int): Board {
        // Fallback: carrom board typically fills 85% of portrait screen width
        val margin = fw * 0.07f
        val size   = fw - margin * 2
        val top    = fh * 0.08f
        return Board(margin, top, margin + size, top + size)
    }

    // ── Color-based blob detection ────────────────────────────────────────────

    enum class PuckColor { TEAL, PINK, CYAN }

    private fun matchColor(r: Int, g: Int, b: Int, target: PuckColor): Boolean {
        return when (target) {
            // YOUR pucks: teal/dark-cyan  R<85 G>85 B>85
            PuckColor.TEAL -> r < 90 && g > 80 && b > 80 && (g + b) > r * 2.2f
            // Opponent: bright pink/magenta  R>150 G<75 B<120
            PuckColor.PINK -> r > 145 && g < 80 && b < 125 && r > g * 2.2f
            // Queen: cyan-blue  B>120 G>90 R<135 B>=G
            PuckColor.CYAN -> b > 115 && g > 85 && r < 140 && b >= g - 10 && b > r + 20
        }
    }

    private fun detectColorPucks(pixels: IntArray, w: Int, l: Int, t: Int, r: Int, b: Int, color: PuckColor): List<Circle> {
        val seeds = mutableListOf<Pair<Int,Int>>()
        for (y in t until b step 2) {
            for (x in l until r step 2) {
                val p = pixels[y*w+x]
                if (matchColor(Color.red(p), Color.green(p), Color.blue(p), color)) seeds.add(x to y)
            }
        }
        if (seeds.isEmpty()) return emptyList()

        return clusterPts(seeds, 22f)
            .filter { it.size >= 6 }
            .mapNotNull { cluster ->
                leastSquaresCircle(cluster)?.let { (cx, cy, rad) ->
                    if (rad < 4f || rad > 35f) null
                    else Circle(cx, cy, rad, cx, cy, minOf(1f, cluster.size / 60f))
                }
            }
            .let { dedup(it, 20f) }
    }

    // ── Striker detection (brightest blob) ───────────────────────────────────

    private fun detectStriker(pixels: IntArray, w: Int, l: Int, t: Int, r: Int, b: Int): Circle? {
        val seeds = mutableListOf<Pair<Int,Int>>()
        for (y in t until b step 2) {
            for (x in l until r step 2) {
                val p = pixels[y*w+x]
                val rv = Color.red(p); val g = Color.green(p); val bv = Color.blue(p)
                val bright = (rv + g + bv) / 3f
                val maxC = maxOf(rv, g, bv).toFloat()
                val minC = minOf(rv, g, bv).toFloat()
                val sat  = if (maxC > 0) (maxC - minC) / maxC else 0f
                if (bright > 185f && sat < 0.22f) seeds.add(x to y)
            }
        }
        if (seeds.isEmpty()) return null

        return clusterPts(seeds, 25f)
            .filter { it.size >= 8 }
            .mapNotNull { cluster ->
                leastSquaresCircle(cluster)?.let { (cx, cy, rad) ->
                    if (rad < 6f || rad > 38f) null
                    else {
                        // Find brightest pixel = precise center dot
                        var bestB = 0f; var bcx = cx; var bcy = cy
                        cluster.forEach { (px, py) ->
                            val p = pixels[py*w+px]
                            val bright = (Color.red(p)+Color.green(p)+Color.blue(p))/3f
                            if (bright > bestB) { bestB = bright; bcx = px.toFloat(); bcy = py.toFloat() }
                        }
                        Circle(cx, cy, rad, bcx, bcy, 1f)
                    }
                }
            }
            .maxByOrNull { it.radius }
    }

    // ── Least-squares circle fit (sub-pixel accuracy) ─────────────────────────
    // Fits exact circle to blob pixels using algebraic method

    private fun leastSquaresCircle(pts: List<Pair<Int,Int>>): Triple<Float,Float,Float>? {
        if (pts.size < 5) return null
        val n = pts.size.toDouble()
        var sx=0.0; var sy=0.0; var sx2=0.0; var sy2=0.0
        var sx3=0.0; var sy3=0.0; var sxy=0.0; var sx2y=0.0; var sxy2=0.0
        pts.forEach { (xi, yi) ->
            val x=xi.toDouble(); val y=yi.toDouble()
            val x2=x*x; val y2=y*y
            sx+=x; sy+=y; sx2+=x2; sy2+=y2
            sx3+=x2*x; sy3+=y2*y; sxy+=x*y; sx2y+=x2*y; sxy2+=x*y2
        }
        val A = n*sx2 - sx*sx
        val B = n*sxy - sx*sy
        val C = n*sy2 - sy*sy
        val D = 0.5*(n*sx2y - sx*sy2 + n*sx3 - sx*sx2)
        val E = 0.5*(n*sxy2 - sy*sx2 + n*sy3 - sy*sy2)
        val det = A*C - B*B
        if (abs(det) < 1e-6) return null
        val cx = ((D*C - B*E) / det).toFloat()
        val cy = ((A*E - B*D) / det).toFloat()
        val rad = pts.map { (xi,yi) -> sqrt((xi-cx)*(xi-cx)+(yi-cy)*(yi-cy).toDouble()) }.average().toFloat()
        return Triple(cx, cy, rad)
    }

    // ── Temporal smoothing (reduce jitter) ────────────────────────────────────

    private fun smoothStriker(new: Circle): Circle {
        val prev = prevStriker ?: run { prevStriker = new; return new }
        val alpha = 0.65f  // weight for new reading
        val sx = prev.x * (1-alpha) + new.x * alpha
        val sy = prev.y * (1-alpha) + new.y * alpha
        val sr = prev.radius * (1-alpha) + new.radius * alpha
        val result = Circle(sx, sy, sr, new.centerDotX, new.centerDotY, new.confidence)
        prevStriker = result
        return result
    }

    // ── Force/power bar detection ─────────────────────────────────────────────

    private fun detectForceBar(pixels: IntArray, w: Int, h: Int): Float {
        var gold = 0; var total = 0
        for (y in (h*0.80f).toInt() until (h*0.92f).toInt() step 2) {
            for (x in 0 until w step 2) {
                val p = pixels[y*w+x]
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (g > 150 && r > 140 && b < 90) gold++
                total++
            }
        }
        val ratio = if (total > 0) gold.toFloat() / total else 0f
        return if (ratio < 0.008f) 0.80f else (ratio * 10f).coerceIn(0.2f, 1.0f)
    }

    private fun detectPowerBar(pixels: IntArray, w: Int, h: Int): Float {
        var colored = 0; var total = 0
        for (y in 0 until (h * 0.07f).toInt() step 2) {
            for (x in 0 until w step 2) {
                val p = pixels[y*w+x]
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (g > 160 && g > r*1.3f && g > b*1.3f) colored++
                total++
            }
        }
        val ratio = if (total > 0) colored.toFloat() / total else 0f
        return if (ratio < 0.004f) 0.0f else (ratio * 18f).coerceIn(0f, 1f)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun clusterPts(pts: List<Pair<Int,Int>>, radius: Float): List<List<Pair<Int,Int>>> {
        val used = BooleanArray(pts.size); val clusters = mutableListOf<List<Pair<Int,Int>>>(); val r2 = radius*radius
        for (i in pts.indices) {
            if (used[i]) continue
            val cluster = mutableListOf<Pair<Int,Int>>(); val q = ArrayDeque<Int>()
            q.add(i); used[i] = true
            while (q.isNotEmpty()) {
                val cur = q.removeFirst(); cluster.add(pts[cur])
                for (j in pts.indices) {
                    if (used[j]) continue
                    val dx=(pts[j].first-pts[cur].first).toFloat(); val dy=(pts[j].second-pts[cur].second).toFloat()
                    if (dx*dx+dy*dy<=r2) { used[j]=true; q.add(j) }
                }
            }
            clusters.add(cluster)
        }
        return clusters
    }

    private fun dedup(circles: List<Circle>, minDist: Float): List<Circle> {
        val result = mutableListOf<Circle>()
        for (c in circles.sortedByDescending { it.confidence }) {
            if (result.none { sqrt((it.x-c.x).pow(2)+(it.y-c.y).pow(2)) < minDist }) result.add(c)
        }
        return result
    }
}
