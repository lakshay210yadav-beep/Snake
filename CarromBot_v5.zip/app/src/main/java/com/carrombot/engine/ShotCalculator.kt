package com.carrombot.engine

import com.carrombot.detection.BoardDetector
import kotlin.math.*

class ShotCalculator {

    data class ShotResult(
        val dragFromX: Float, val dragToX: Float, val baselineY: Float,
        val swipeStartX: Float, val swipeStartY: Float,
        val swipeEndX: Float, val swipeEndY: Float,
        val swipeLength: Float,
        val targetPuck: BoardDetector.Circle,
        val targetPocket: Pair<Float, Float>,
        val confidence: Float,
        val shotType: ShotType,
        val power: Float
    )

    enum class ShotType { DIRECT, BANK, QUEEN }

    fun calculate(state: BoardDetector.GameState, sw: Int, sh: Int): ShotResult? {
        val board = state.board ?: return null
        if (state.striker == null) return null

        val pockets   = board.pockets
        val puckR     = board.puckRadius
        val strikerR  = board.strikerRadius
        val boardDiag = hypot(board.width, board.height)

        // Baseline: use striker center dot for precision
        val baselineY = state.striker.centerDotY
        val baseCX    = state.striker.centerDotX
        val minX      = board.left + strikerR
        val maxX      = board.right - strikerR

        val force = (state.strikerForce + state.powerLevel * 0.25f).coerceIn(0.3f, 1f)

        var best: ShotResult? = null
        var bestScore = -1f

        fun try_(puck: BoardDetector.Circle, pocket: Pair<Float,Float>, type: ShotType) {
            val s = calcShot(baseCX, baselineY, puck, pocket, state, force, type, puckR, strikerR, minX, maxX, boardDiag)
            if (s != null && s.confidence > bestScore) { bestScore = s.confidence; best = s }
        }

        // Priority 1: Queen
        state.queen?.let { q -> pockets.forEach { try_(q, it, ShotType.QUEEN) } }
        // Priority 2: Player pucks
        state.playerPucks.forEach { p -> pockets.forEach { try_(p, it, ShotType.DIRECT) } }
        // Priority 3: Banks
        if (bestScore < 0.40f) {
            state.playerPucks.forEach { puck ->
                pockets.forEach { pocket ->
                    listOf(
                        2*board.left   - pocket.first  to pocket.second,
                        2*board.right  - pocket.first  to pocket.second,
                        pocket.first   to 2*board.top  - pocket.second,
                        pocket.first   to 2*board.bottom - pocket.second
                    ).forEach { ref ->
                        val s = calcShot(baseCX, baselineY, puck, ref, state, force, ShotType.BANK, puckR, strikerR, minX, maxX, boardDiag)
                        if (s != null) {
                            val adj = s.confidence * 0.60f
                            if (adj > bestScore) { bestScore = adj; best = s.copy(confidence = adj, targetPocket = pocket) }
                        }
                    }
                }
            }
        }
        return best
    }

    private fun calcShot(
        baseCX: Float, baselineY: Float,
        puck: BoardDetector.Circle, pocket: Pair<Float,Float>,
        state: BoardDetector.GameState, force: Float, type: ShotType,
        puckR: Float, strikerR: Float, minX: Float, maxX: Float, boardDiag: Float
    ): ShotResult? {
        val dx = pocket.first - puck.x; val dy = pocket.second - puck.y
        val dist = hypot(dx, dy); if (dist < 1f) return null
        val nx = dx/dist; val ny = dy/dist

        // Exact contact point on puck circumference
        val cx = puck.centerDotX - nx*(puckR + strikerR)
        val cy = puck.centerDotY - ny*(puckR + strikerR)
        val strikerX = cx.coerceIn(minX, maxX)

        val all = state.playerPucks + state.opponentPucks + listOfNotNull(state.queen)
        if (!pathClear(strikerX, baselineY, cx, cy, puck, all, puckR)) return null
        if (!pathClear(puck.centerDotX, puck.centerDotY, pocket.first, pocket.second, puck, all, puckR)) return null

        val strikerToPuck = hypot(cx - strikerX, cy - baselineY)
        val totalTravel   = strikerToPuck + dist
        val travelRatio   = (totalTravel / (boardDiag * 0.85f)).coerceIn(0f, 1f)

        val MIN_SWIPE = 60f; val MAX_SWIPE = 320f
        val swipeLen  = (MIN_SWIPE + travelRatio*(MAX_SWIPE - MIN_SWIPE))
            .let { it * (0.38f + force * 0.62f) }
            .coerceIn(MIN_SWIPE, MAX_SWIPE)

        val sdx = cx - strikerX; val sdy = cy - baselineY
        val sd  = hypot(sdx, sdy)
        val snx = if (sd > 0) sdx/sd else 0f
        val sny = if (sd > 0) sdy/sd else -1f

        val conf = abs(ny)*0.30f + (1f - travelRatio)*0.50f + if (swipeLen < MAX_SWIPE*0.95f) 0.20f else 0f

        return ShotResult(
            dragFromX=baseCX, dragToX=strikerX, baselineY=baselineY,
            swipeStartX=strikerX, swipeStartY=baselineY,
            swipeEndX=strikerX+snx*swipeLen, swipeEndY=baselineY+sny*swipeLen,
            swipeLength=swipeLen, targetPuck=puck, targetPocket=pocket,
            confidence=conf, shotType=type, power=swipeLen/MAX_SWIPE
        )
    }

    private fun pathClear(fx: Float, fy: Float, tx: Float, ty: Float,
        excl: BoardDetector.Circle, pucks: List<BoardDetector.Circle>, puckR: Float): Boolean {
        val dx=tx-fx; val dy=ty-fy; val d=hypot(dx,dy); if (d<1f) return true
        for (p in pucks) {
            if (hypot(p.x-excl.x, p.y-excl.y) < 5f) continue
            val t=((p.x-fx)*dx+(p.y-fy)*dy)/(d*d)
            if (t<0||t>1) continue
            if (hypot(p.x-(fx+t*dx), p.y-(fy+t*dy)) < puckR*2.1f) return false
        }
        return true
    }
}
