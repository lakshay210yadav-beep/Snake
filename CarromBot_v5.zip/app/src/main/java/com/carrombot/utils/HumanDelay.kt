package com.carrombot.utils
import kotlin.random.Random
object HumanDelay { fun get(min: Int, max: Int): Long = Random.nextLong(min.toLong(), max.toLong()) }
