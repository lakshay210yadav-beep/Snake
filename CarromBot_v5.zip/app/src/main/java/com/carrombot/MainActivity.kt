package com.carrombot

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.carrombot.overlay.OverlayService

class MainActivity : AppCompatActivity() {
    private lateinit var btnPermissions: Button
    private lateinit var btnLaunchGame: Button
    private lateinit var btnToggleBot: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvSteps: TextView
    private val pm by lazy { getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    private val handler = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 800) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setContentView(R.layout.activity_main)
        btnPermissions = findViewById(R.id.btnPermissions)
        btnLaunchGame  = findViewById(R.id.btnLaunchGame)
        btnToggleBot   = findViewById(R.id.btnToggleBot)
        tvStatus       = findViewById(R.id.tvStatus)
        tvSteps        = findViewById(R.id.tvSteps)
        btnPermissions.setOnClickListener { grantPerms() }
        btnLaunchGame.setOnClickListener  { launchGame() }
        btnToggleBot.setOnClickListener   { toggleBot() }
    }

    override fun onResume() { super.onResume(); handler.post(refresher) }
    override fun onPause()  { super.onPause();  handler.removeCallbacks(refresher) }

    private fun refresh() {
        val ov      = Settings.canDrawOverlays(this)
        val ac      = isAccOn()
        val running = ScreenCaptureService.instance != null
        val active  = OverlayService.instance?.botActive == true
        val allPerms = ov && ac

        tvSteps.text = "${if(ov)"✓" else "✗"}  Overlay permission\n" +
                       "${if(ac)"✓" else "✗"}  Accessibility service\n" +
                       "${if(running)"✓" else "○"}  Screen capture"

        tvStatus.text = when {
            !ov || !ac -> "⚠ Permissions needed"
            !running   -> "Ready — tap LAUNCH GAME"
            active     -> "● AutoPlay RUNNING"
            else       -> "○ AutoPlay OFF"
        }
        tvStatus.setTextColor(when {
            !ov || !ac -> Color.parseColor("#FFD700")
            active     -> Color.parseColor("#00E676")
            else       -> Color.parseColor("#00BFA5")
        })

        btnPermissions.text = if (allPerms) "PERMISSIONS OK ✓" else "GRANT PERMISSIONS"
        btnPermissions.alpha = if (!allPerms) 1f else 0.5f
        btnPermissions.backgroundTintList = ColorStateList.valueOf(
            Color.parseColor(if (allPerms) "#388E3C" else "#FFD700"))
        btnPermissions.setTextColor(Color.parseColor(if (allPerms) "#FFFFFF" else "#111118"))

        btnLaunchGame.isEnabled = allPerms
        btnLaunchGame.alpha     = if (allPerms) 1f else 0.4f

        btnToggleBot.isEnabled  = running
        btnToggleBot.alpha      = if (running) 1f else 0.4f
        btnToggleBot.text       = if (active) "■  STOP AUTOPLAY" else "▶  START AUTOPLAY"
        btnToggleBot.backgroundTintList = ColorStateList.valueOf(
            Color.parseColor(if (active) "#E8185A" else "#00BFA5"))
    }

    private fun grantPerms() {
        when {
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, "Allow 'Display over other apps' → come back", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
            !isAccOn() -> {
                Toast.makeText(this, "Find CarromBot → enable it → come back", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            ScreenCaptureService.instance == null ->
                startActivityForResult(pm.createScreenCaptureIntent(), 1001)
            else ->
                Toast.makeText(this, "All permissions granted!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchGame() {
        if (OverlayService.instance == null)
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        if (ScreenCaptureService.instance == null) {
            startActivityForResult(pm.createScreenCaptureIntent(), 1001); return
        }
        openCarromPool()
    }

    private fun openCarromPool() {
        val pkg = "com.miniclip.carrom"
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } else {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                    .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
            }
        }
    }

    private fun toggleBot() {
        val svc = OverlayService.instance ?: run {
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            handler.postDelayed({
                OverlayService.instance?.let { it.botActive = true; ScreenCaptureService.isPaused = false }
                openCarromPool(); refresh()
            }, 500); return
        }
        svc.botActive = !svc.botActive
        ScreenCaptureService.isPaused = !svc.botActive
        if (svc.botActive) openCarromPool()
        refresh()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1001 && res == Activity.RESULT_OK && data != null) {
            ContextCompat.startForegroundService(this,
                Intent(this, ScreenCaptureService::class.java)
                    .putExtra("rc", res).putExtra("data", data))
            if (OverlayService.instance == null)
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            ScreenCaptureService.isPaused = true
            Toast.makeText(this, "Ready! Tap START AUTOPLAY.", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    private fun isAccOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName, ignoreCase = true)
    }
}
