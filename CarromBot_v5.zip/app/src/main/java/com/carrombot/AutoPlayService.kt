package com.carrombot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.carrombot.engine.ShotCalculator
import com.carrombot.overlay.OverlayService
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.random.Random

class AutoPlayService : AccessibilityService() {
    companion object {
        var instance: AutoPlayService? = null
        const val GAME_PKG = "com.miniclip.carrom"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope   = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var busy    = false
    private var lastMs  = 0L
    private val GAP     = 1200L

    override fun onServiceConnected() {
        instance = this
        // Start overlay immediately when accessibility connects
        val i = Intent(this, OverlayService::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startService(i)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        // Detect when Carrom Pool is in foreground — show/hide icon
        val pkg = e?.packageName?.toString() ?: return
        val isGame = pkg == GAME_PKG
        if (isGame) OverlayService.instance?.showIcon() else OverlayService.instance?.hideIcon()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel(); instance = null; super.onDestroy()
    }

    fun executeShot(shot: ShotCalculator.ShotResult) {
        val now = System.currentTimeMillis()
        if (busy || now - lastMs < GAP) return
        scope.launch {
            busy = true; lastMs = System.currentTimeMillis()
            try {
                if (abs(shot.dragToX - shot.dragFromX) > 12f) {
                    drag(shot.dragFromX, shot.baselineY, shot.dragToX, shot.baselineY)
                    delay(Random.nextLong(80, 150))
                }
                swipe(shot)
            } finally { busy = false }
        }
    }

    private fun drag(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p   = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val dur = (abs(x2 - x1) * 0.8f).coerceIn(80f, 280f).toLong()
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, dur)).build(), null, null)
        Thread.sleep(dur + 20)
    }

    private fun swipe(shot: ShotCalculator.ShotResult) {
        val nx = Random.nextFloat() * 3f - 1.5f
        val ny = Random.nextFloat() * 2f - 1f
        val p  = Path().apply {
            moveTo(shot.swipeStartX + nx, shot.swipeStartY)
            lineTo(shot.swipeEndX + nx, shot.swipeEndY + ny)
        }
        val dur = when {
            shot.swipeLength > 250f -> 55L
            shot.swipeLength > 130f -> 80L
            else -> 110L
        }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, dur)).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {}
                override fun onCancelled(g: GestureDescription?) {}
            }, handler)
    }
}
