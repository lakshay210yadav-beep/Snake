package com.carrombot.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.view.*
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.carrombot.ScreenCaptureService
import com.carrombot.detection.BoardDetector
import com.carrombot.engine.ShotCalculator
import kotlinx.coroutines.*

class OverlayService : Service() {
    companion object {
        const val CH = "CB_OVL"; const val NID = 2
        const val GAME_PKG = "com.miniclip.carrom"
        var instance: OverlayService? = null
    }

    private var wm: WindowManager? = null
    private var predView: PredView? = null
    private var iconView: IconView? = null
    private var popupView: PopupView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    var botActive = false
    private var popupShown = false

    override fun onCreate() {
        super.onCreate(); instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        mkCh(); addPred(); addIcon(); startLoop()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForeground(NID, mkNote()); return START_STICKY
    }

    private fun addIcon() {
        iconView = IconView(this) { onIconTap() }
        val lp = mkLP(64.dp, 64.dp).apply { gravity = Gravity.TOP or Gravity.END; x = 8.dp; y = 200.dp }
        wm?.addView(iconView, lp); makeDraggable(iconView!!)
    }

    private fun onIconTap() {
        if (botActive) { stopBot() } else { if (!popupShown) showPopup() else hidePopup() }
    }

    fun showIcon() { iconView?.visibility = android.view.View.VISIBLE }
    fun hideIcon() { iconView?.visibility = android.view.View.GONE }

    private fun stopBot() {
        botActive = false; ScreenCaptureService.isPaused = true; iconView?.setActive(false)
    }

    fun startBot() {
        botActive = true; ScreenCaptureService.isPaused = false
        iconView?.setActive(true); hidePopup(); launchGame()
    }

    private fun showPopup() {
        if (popupShown) return
        popupView = PopupView(this, ScreenCaptureService.latestShot, ScreenCaptureService.latestState,
            onClose  = { hidePopup() },
            onLaunch = { launchGame(); hidePopup() },
            onStart  = { startBot() }
        )
        wm?.addView(popupView, mkLP(310.dp, 280.dp).apply { gravity = Gravity.CENTER })
        popupShown = true
    }

    private fun hidePopup() {
        popupView?.let { runCatching { wm?.removeView(it) } }; popupView = null; popupShown = false
    }

    private fun addPred() {
        predView = PredView(this)
        val lp = mkLP(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm?.addView(predView, lp)
    }

    private fun startLoop() {
        scope.launch {
            while (isActive) {
                if (botActive) predView?.update(ScreenCaptureService.latestShot, ScreenCaptureService.latestState)
                else predView?.update(null, null)
                delay(80)
            }
        }
    }

    fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(GAME_PKG)
        if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
        else Toast.makeText(this, "Carrom Pool not found", Toast.LENGTH_LONG).show()
    }

    private fun makeDraggable(v: View) {
        var ox=0; var oy=0; var drag=false; var t0=0L
        v.setOnTouchListener { view, e ->
            val lp = view.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ox=e.rawX.toInt()-lp.x; oy=e.rawY.toInt()-lp.y; t0=System.currentTimeMillis(); drag=false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX-ox-lp.x)>8||Math.abs(e.rawY-oy-lp.y)>8) drag=true; if(drag){lp.x=e.rawX.toInt()-ox; lp.y=e.rawY.toInt()-oy; wm?.updateViewLayout(view,lp)} }
                MotionEvent.ACTION_UP   -> { if (!drag && System.currentTimeMillis()-t0<350) onIconTap() }
            }; true
        }
    }

    private fun mkLP(w: Int, h: Int) = WindowManager.LayoutParams(w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT)

    private fun mkCh() { getSystemService(NotificationManager::class.java)
        .createNotificationChannel(NotificationChannel(CH, "CarromBot", NotificationManager.IMPORTANCE_LOW)) }
    private fun mkNote() = NotificationCompat.Builder(this, CH)
        .setContentTitle("CarromBot").setContentText("Tap icon to play")
        .setSmallIcon(android.R.drawable.ic_media_play).setPriority(NotificationCompat.PRIORITY_LOW).build()

    override fun onDestroy() {
        scope.cancel()
        listOf(predView, iconView, popupView).forEach { it?.let { v -> runCatching { wm?.removeView(v) } } }
        instance = null; super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null
    val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}

// ── Floating Icon ─────────────────────────────────────────────────────────────

class IconView(ctx: Context, private val onTap: () -> Unit) : View(ctx) {
    private var active = false
    fun setActive(a: Boolean) { active = a; invalidate() }

    private val bgP  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(10f, BlurMaskFilter.Blur.NORMAL) }
    private val iconP = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx=width/2f; val cy=height/2f; val r=width/2f-4f
        // Glow
        glowP.color = if(active) Color.argb(70,0,255,120) else Color.argb(40,0,0,0)
        c.drawCircle(cx, cy+2f, r, glowP)
        // Fill
        bgP.color = if(active) Color.argb(235,0,140,60) else Color.argb(230,15,15,25)
        c.drawCircle(cx, cy, r, bgP)
        // Ring
        ringP.color = if(active) Color.argb(255,0,255,120) else Color.argb(140,100,100,120)
        c.drawCircle(cx, cy, r, ringP)
        // Inner ring (autoplay indicator)
        if (active) {
            ringP.color = Color.argb(100,0,255,120); ringP.strokeWidth=1f
            c.drawCircle(cx, cy, r*0.72f, ringP); ringP.strokeWidth=2.5f
        }
        // Play/Pause symbol
        iconP.color = Color.WHITE
        if (active) {
            // Pause bars
            c.drawRoundRect(cx-8f,cy-9f,cx-2f,cy+9f,2f,2f,iconP)
            c.drawRoundRect(cx+2f,cy-9f,cx+8f,cy+9f,2f,2f,iconP)
        } else {
            // Play triangle
            val p = Path().apply { moveTo(cx-5f,cy-10f); lineTo(cx+11f,cy); lineTo(cx-5f,cy+10f); close() }
            c.drawPath(p, iconP)
        }
        // Center dot (always visible — indicates "bot ready")
        iconP.color = if(active) Color.argb(255,0,255,120) else Color.argb(180,255,215,0)
        c.drawCircle(cx, cy, 3f, iconP)
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
}

// ── Popup Window ──────────────────────────────────────────────────────────────

class PopupView(ctx: Context,
    private val shot: ShotCalculator.ShotResult?,
    private val state: BoardDetector.GameState?,
    private val onClose:()->Unit, private val onLaunch:()->Unit, private val onStart:()->Unit
) : View(ctx) {
    private val launchR=RectF(); private val startR=RectF(); private val closeR=RectF()
    private val bg  = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(248,10,10,20)}
    private val bdr = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(210,80,60,200);style=Paint.Style.STROKE;strokeWidth=1.8f}
    private val ttl = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(255,255,210,0);textSize=20f;typeface=Typeface.DEFAULT_BOLD}
    private val bod = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE;textSize=13.5f}
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(170,150,150,180);textSize=11.5f}
    private val grn = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(255,0,210,90);textSize=12.5f}
    private val lbp = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(210,70,50,190)}
    private val sbp = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(210,0,130,60)}
    private val cbp = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(180,170,40,40)}

    override fun onMeasure(w:Int,h:Int)=setMeasuredDimension(MeasureSpec.getSize(w),(280*resources.displayMetrics.density).toInt())

    override fun onDraw(c: Canvas) {
        val w=width.toFloat(); val p=16f
        c.drawRoundRect(4f,4f,w-4f,height-4f,18f,18f,bg)
        c.drawRoundRect(4f,4f,w-4f,height-4f,18f,18f,bdr)
        closeR.set(w-44f,8f,w-8f,44f)
        c.drawRoundRect(closeR,9f,9f,cbp)
        Paint(Paint.ANTI_ALIAS_FLAG).also{it.color=Color.WHITE;it.textSize=16f;it.typeface=Typeface.DEFAULT_BOLD;c.drawText("X",w-30f,30f,it)}
        var y=p+4f
        c.drawText("CarromBot", p, y+ttl.textSize, ttl); y+=ttl.textSize+3f
        c.drawText("Carrom Pool  |  com.miniclip.carrom", p, y+sub.textSize, sub); y+=sub.textSize+8f
        // Board info
        state?.board?.let { b ->
            c.drawText("Board: ${b.width.toInt()}x${b.height.toInt()}px  Puck R: ${b.puckRadius.toInt()}px", p, y+sub.textSize, sub)
            y+=sub.textSize+4f
            c.drawText("Pucks: ${state.playerPucks.size} yours  ${state.opponentPucks.size} opp  Queen: ${if(state.queen!=null)"yes" else "no"}", p, y+grn.textSize, grn)
            y+=grn.textSize+6f
        }
        if (shot!=null) {
            val t=when(shot.shotType){ShotCalculator.ShotType.QUEEN->"Queen Shot";ShotCalculator.ShotType.BANK->"Bank Shot";else->"Direct Pocket"}
            c.drawText(t, p, y+bod.textSize, bod); y+=bod.textSize+3f
            c.drawText("Power: ${(shot.power*100).toInt()}%   Conf: ${(shot.confidence*100).toInt()}%", p, y+grn.textSize, grn); y+=grn.textSize+10f
        } else { c.drawText("Waiting for board detection...", p, y+sub.textSize, sub); y+=sub.textSize+12f }
        val bh=40f; val bw=w-p*2
        launchR.set(p,y,p+bw,y+bh); c.drawRoundRect(launchR,10f,10f,lbp); c.drawText("Open Carrom Pool",p+10f,y+bh*0.65f,bod); y+=bh+8f
        startR.set(p,y,p+bw,y+bh); c.drawRoundRect(startR,10f,10f,sbp); c.drawText("Start AutoPlay",p+10f,y+bh*0.65f,bod)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if(e.action==MotionEvent.ACTION_UP) when{closeR.contains(e.x,e.y)->onClose();launchR.contains(e.x,e.y)->onLaunch();startR.contains(e.x,e.y)->onStart()}
        return true
    }
    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
}

// ── Prediction Overlay — NO board rectangle, only circles + lines ─────────────

class PredView(ctx: Context) : View(ctx) {
    private var shot: ShotCalculator.ShotResult? = null
    private var state: BoardDetector.GameState? = null

    // Teal dashed — aim line
    private val aimP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(210,0,210,170); strokeWidth=3f; style=Paint.Style.STROKE
        pathEffect=DashPathEffect(floatArrayOf(13f,6f),0f)
    }
    // White solid — shot line
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(215,255,255,255); strokeWidth=3.5f; style=Paint.Style.STROKE
    }
    // Arrow
    private val arrP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(200,0,210,170); strokeWidth=3.5f; style=Paint.Style.STROKE
    }
    // Pocket dot
    private val pktP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(200,255,60,0); style=Paint.Style.FILL
    }
    // Striker green ring
    private val sRingP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(210,0,255,140); style=Paint.Style.STROKE; strokeWidth=2.5f
    }
    // Striker center dot — bright yellow
    private val sDotP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(255,255,220,0); style=Paint.Style.FILL
    }
    // Target puck yellow ring
    private val tRingP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(200,255,215,0); style=Paint.Style.STROKE; strokeWidth=2.2f
    }
    // Target puck center dot
    private val tDotP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(255,0,255,140); style=Paint.Style.FILL
    }
    // Queen cyan ring
    private val qRingP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(220,0,200,255); style=Paint.Style.STROKE; strokeWidth=2.8f
    }
    // All puck outlines (non-target)
    private val myPuckP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(130,0,220,170); style=Paint.Style.STROKE; strokeWidth=1.5f
    }
    private val oppPuckP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.argb(120,255,80,130); style=Paint.Style.STROKE; strokeWidth=1.5f
    }
    private val txtP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color=Color.WHITE; textSize=20f; typeface=Typeface.DEFAULT_BOLD
    }
    private val barBgP = Paint().apply { color=Color.argb(110,0,0,0) }

    fun update(s: ShotCalculator.ShotResult?, bs: BoardDetector.GameState?) {
        shot=s; state=bs; postInvalidate()
    }

    override fun onDraw(c: Canvas) {
        val bs = state
        val s  = shot

        // Draw all detected puck boundaries (faint rings)
        bs?.let { gs ->
            gs.playerPucks.forEach { p ->
                c.drawCircle(p.x, p.y, p.radius, myPuckP)
                // Center dot on every puck
                c.drawCircle(p.centerDotX, p.centerDotY, 2f, myPuckP)
            }
            gs.opponentPucks.forEach { p ->
                c.drawCircle(p.x, p.y, p.radius, oppPuckP)
                c.drawCircle(p.centerDotX, p.centerDotY, 2f, oppPuckP)
            }
            gs.queen?.let { q ->
                c.drawCircle(q.x, q.y, q.radius + 3f, qRingP)
                c.drawCircle(q.centerDotX, q.centerDotY, 3f, qRingP)
            }
            gs.striker?.let { st ->
                c.drawCircle(st.x, st.y, st.radius + 5f, sRingP)
                c.drawCircle(st.centerDotX, st.centerDotY, 4.5f, sDotP)
            }
        }

        s ?: return

        // Target puck: bright ring + precise center dot
        c.drawCircle(s.targetPuck.x, s.targetPuck.y, s.targetPuck.radius + 4f, tRingP)
        c.drawCircle(s.targetPuck.centerDotX, s.targetPuck.centerDotY, 4f, tDotP)

        // Queen highlight if queen shot
        if (s.shotType == ShotCalculator.ShotType.QUEEN) {
            bs?.queen?.let { q -> c.drawCircle(q.x, q.y, q.radius + 6f, qRingP) }
        }

        // Aim line: striker center → puck center (teal dashed)
        c.drawLine(s.swipeStartX, s.swipeStartY, s.targetPuck.centerDotX, s.targetPuck.centerDotY, aimP)

        // Shot line: puck center → pocket (white solid)
        c.drawLine(s.targetPuck.centerDotX, s.targetPuck.centerDotY, s.targetPocket.first, s.targetPocket.second, lineP)

        // Pocket
        c.drawCircle(s.targetPocket.first, s.targetPocket.second, 11f, pktP)

        // Swipe arrow
        c.drawLine(s.swipeStartX, s.swipeStartY, s.swipeEndX, s.swipeEndY, arrP)
        val a=Math.atan2((s.swipeEndY-s.swipeStartY).toDouble(),(s.swipeEndX-s.swipeStartX).toDouble())
        val sz=15f; val sp=Math.PI/6
        c.drawLine(s.swipeEndX,s.swipeEndY,(s.swipeEndX-sz*Math.cos(a-sp)).toFloat(),(s.swipeEndY-sz*Math.sin(a-sp)).toFloat(),arrP)
        c.drawLine(s.swipeEndX,s.swipeEndY,(s.swipeEndX-sz*Math.cos(a+sp)).toFloat(),(s.swipeEndY-sz*Math.sin(a+sp)).toFloat(),arrP)

        // HUD
        val lbl=when(s.shotType){ShotCalculator.ShotType.QUEEN->"Queen";ShotCalculator.ShotType.BANK->"Bank";else->"Direct"}
        c.drawText(lbl, 12f, 58f, txtP)
        c.drawText("${(s.power*100).toInt()}%", 12f, 80f, txtP)
        val ratio=s.power.coerceIn(0f,1f); val bx=12f; val by=height-40f; val bw=150f; val bh=10f
        c.drawRect(bx,by,bx+bw,by+bh,barBgP)
        Paint().also{it.color=when{ratio>0.7f->Color.rgb(255,50,50);ratio>0.4f->Color.rgb(255,185,0);else->Color.rgb(0,195,85)}
            c.drawRect(bx,by,bx+bw*ratio,by+bh,it)}
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }
}
