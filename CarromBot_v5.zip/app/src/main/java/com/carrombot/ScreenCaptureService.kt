package com.carrombot

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.carrombot.detection.BoardDetector
import com.carrombot.engine.ShotCalculator
import com.carrombot.overlay.OverlayService
import kotlinx.coroutines.*

class ScreenCaptureService : Service() {
    companion object {
        const val CH = "CB_CAP"; const val NID = 1
        var instance: ScreenCaptureService? = null
        @Volatile var isPaused = true
        @Volatile var latestShot: ShotCalculator.ShotResult? = null
        @Volatile var latestState: BoardDetector.GameState? = null
    }

    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val calc = ShotCalculator()
    private var sw = 0; private var sh = 0; private var dpi = 0

    override fun onCreate() { super.onCreate(); instance = this; mkCh() }

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        startForeground(NID, mkNote())
        val rc   = intent?.getIntExtra("rc", -1) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val m    = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels; sh = m.heightPixels; dpi = m.densityDpi
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = pm.getMediaProjection(rc, data)
        startCapture(); return START_STICKY
    }

    private fun startCapture() {
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vDisplay = projection?.createVirtualDisplay("CB", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        scope.launch {
            while (isActive) {
                val t = System.currentTimeMillis()
                if (!isPaused) processFrame()
                delay(maxOf(0L, 120L - (System.currentTimeMillis() - t)))
            }
        }
    }

    private suspend fun processFrame() = withContext(Dispatchers.Default) {
        try {
            val img = reader?.acquireLatestImage() ?: return@withContext
            val plane = img.planes[0]
            val buf = plane.buffer; val ps = plane.pixelStride; val rs = plane.rowStride
            val bmp = Bitmap.createBitmap(rs/ps, sh, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf); img.close()
            val cropped = if (bmp.width > sw) Bitmap.createBitmap(bmp, 0, 0, sw, sh) else bmp
            if (cropped != bmp) bmp.recycle()
            val state = BoardDetector.analyze(cropped)
            cropped.recycle()
            latestState = state
            if (state.isValid && !isPaused) {
                val shot = calc.calculate(state, sw, sh)
                latestShot = shot
                shot?.let { AutoPlayService.instance?.executeShot(it) }
            }
        } catch (_: Exception) {}
    }

    private fun mkCh() { getSystemService(NotificationManager::class.java)
        .createNotificationChannel(NotificationChannel(CH, "CarromBot", NotificationManager.IMPORTANCE_LOW)) }
    private fun mkNote() = NotificationCompat.Builder(this, CH)
        .setContentTitle("CarromBot").setContentText("Active")
        .setSmallIcon(android.R.drawable.ic_media_play).setPriority(NotificationCompat.PRIORITY_LOW).build()
    override fun onDestroy() { scope.cancel(); vDisplay?.release(); reader?.close(); projection?.stop(); instance=null; super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
